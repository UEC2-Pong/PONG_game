#include "Keyboard.h"
#include "xgpio.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xil_types.h"

void XGpio_Write(void){
	XGpio_DiscreteWrite(&gpio, 2, output);
	usleep(2500);
}

int main()
{
	XGpio gpio;
	u32 btn, output;
	output = 0x00000200;
	XGpio_Initialize(&gpio, 0);
	XGpio_DiscreteWrite(&gpio, 2, output);

	while (1){
		switch(eKeyboardRead()){
		case BUTTON_W:
			output--;
			XGpio_Write();
			break;
		case BUTTON_S:
			output++;
			XGpio_Write();
			break;
		case RELEASED:
			XGpio_Write();
			break;
		}
	}
}
