#include "xil_types.h"

enum KeyboardState {RELEASED, BUTTON_W, BUTTON_S};\
enum KeyboardState eKeyboardRead(void);
uint8_t IsKeyPressed();
uint8_t GetKey();
extern uint8_t key;
