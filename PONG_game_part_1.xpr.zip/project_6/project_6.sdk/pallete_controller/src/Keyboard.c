#include "Keyboard.h"
#include "xuartlite_l.h"
#include "xil_types.h"

char KeyState = 0;

struct Keyboard {
	uint32_t baseaddr;
	uint8_t key;
};
struct Keyboard sKeyboard;

uint8_t IsKeyPressed() {
	if (!XUartLite_IsReceiveEmpty(sKeyboard.baseaddr)){
		sKeyboard.key = XUartLite_RecvByte(sKeyboard.baseaddr);
		KeyState = 1;
		return 1;
	}
	KeyState = 0;
	return 0;
}

uint8_t GetKey() {
	return sKeyboard.key;
}

enum KeyboardState eKeyboardRead(void){
	if (KeyState == 1){
		if (sKeyboard.key == 'w'){
			return (BUTTON_W);
		}
		else if (sKeyboard.key == 's'){
			return (BUTTON_S);
		}
	}
	else{
		return (RELEASED);
	}
}
