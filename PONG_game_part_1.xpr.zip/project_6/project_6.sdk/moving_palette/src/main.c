// includes
#include "xil_types.h"
#include "xgpio.h"
#include "xparameters.h"
#include "xuartlite_l.h"
#include "xil_printf.h"

uint32_t output = 0x00000200;
uint8_t KeyStatus;

// MAIN LOOP

void CheckingForKeys(uint32_t baseaddr) {
	if(!XUartLite_IsReceiveEmpty(baseaddr)){
		if (XUartLite_RecvByte(baseaddr) == 'w'){
			KeyStatus = 1;
		}
		else if (XUartLite_RecvByte(baseaddr) == 's'){
			KeyStatus = 2;
		}
	}
	else{
		KeyStatus = 0;
	}
}

int main(){
	XGpio gpio;
	XGpio_Initialize(&gpio, 0);
	XGpio_DiscreteWrite(&gpio, 2, output);

	while(1){
		CheckingForKeys(XPAR_AXI_UARTLITE_0_BASEADDR);
		if(KeyStatus == 1) {
			output--;
			xil_printf("pressed: 'w' ");
			XGpio_DiscreteWrite(&gpio, 2, output);
		}
		else if(KeyStatus == 2) {
			output++;
			xil_printf("pressed: 's' ");
			XGpio_DiscreteWrite(&gpio, 2, output);
		}
		else{
		}
	}
	XGpio_DiscreteWrite(&gpio, 2, output);
}
