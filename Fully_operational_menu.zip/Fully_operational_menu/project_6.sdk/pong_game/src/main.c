// includes
#include "xil_printf.h"
#include "xil_types.h"
#include "xgpio.h"
#include "xparameters.h"
#include "xuartlite_l.h"
#include "sleep.h"
// parameters

// functions

uint32_t baseaddr = XPAR_AXI_UARTLITE_0_BASEADDR;

struct Keyboard {
	//uint32_t baseaddr;
	uint8_t key;
};
struct Keyboard sKeyboard;

// MAIN LOOP

int main(){

	XGpio gpio;
	u32 output;
	output = 0x00000200;
	XGpio_Initialize(&gpio, 0);
	XGpio_DiscreteWrite(&gpio, 2, output);

	while(1){
		if((!XUartLite_IsReceiveEmpty(baseaddr))){
			output--;
			xil_printf("key pressed: w");
		}
		XGpio_DiscreteWrite(&gpio, 2, output);
		usleep(2500);
	}
}
