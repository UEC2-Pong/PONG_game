#include "xil_types.h"

void Player1Wins(void);
void Player2Wins(void);
void SendEndGame(void);

