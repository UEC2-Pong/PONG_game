#include "xil_types.h"

enum GameMode 	{SINGLEPLAYER, MULTIPLAYER};
enum ScreenMode {MENU, GAME, CREDITS, OPTIONS} eScreenMode;

void Game(enum GameMode, uint8_t);

