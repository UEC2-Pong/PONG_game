void Credits(void);
void SendCredits(void);
