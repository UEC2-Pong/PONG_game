#include "xil_types.h"

enum KeyStatus  {RELEASED, W, S, I, K, ENTER, ESC};
enum KeyStatus CheckingForKeys(uint32_t);
