#include "xil_types.h"

#define FAST 5
#define MEDIUM 3
#define SLOW 1

void Options(uint8_t *);
void SendOptions(uint8_t, uint8_t);
