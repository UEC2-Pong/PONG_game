// includes
#include "xil_types.h"
#include "xgpio.h"
#include "xparameters.h"
#include "xuartlite_l.h"
#include "xil_printf.h"
#include "sleep.h"

uint32_t gpio_output, gpio2_output; //= 0x00200400;
uint8_t KeyStatus;

void CheckingForKeys(uint32_t baseaddr) {
	if(!XUartLite_IsReceiveEmpty(baseaddr)){
		if (XUartLite_RecvByte(baseaddr) == 'w'){
			KeyStatus = 1;
		}
		else if (XUartLite_RecvByte(baseaddr) == 's'){
			KeyStatus = 2;
		}
	}
	else{
		KeyStatus = 0;
	}
}

// MAIN LOOP

int main(){
	XGpio gpio;
	XGpio_Initialize(&gpio, 0);
	uint32_t left_palette_pos  = 0x00000200;
	uint32_t right_palette_pos = 0x00000200;
	uint32_t ball_xpos 		   = 0x00000200;
	uint32_t ball_ypos 		   = 0x00000200;
	gpio_output  = 0x00100200;
	gpio2_output = 0x00100200;
	XGpio_DiscreteWrite(&gpio, 1, gpio_output);
	XGpio_DiscreteWrite(&gpio, 2, gpio2_output);

	while(1){
		CheckingForKeys(XPAR_AXI_UARTLITE_0_BASEADDR);
		if(KeyStatus == 1) {
			left_palette_pos--;
			right_palette_pos--;
			ball_xpos--;
			ball_ypos--;
			//xil_printf("pressed: 'w' ");
			//XGpio_DiscreteWrite(&gpio, 2, output);
		}
		else if(KeyStatus == 2) {
			left_palette_pos++;
			right_palette_pos++;
			ball_xpos++;
			ball_ypos++;
			//xil_printf("pressed: 's' ");
			//XGpio_DiscreteWrite(&gpio, 2, output);
		}
		else{
		}
	gpio2_output = right_palette_pos;
	gpio2_output = gpio2_output | (left_palette_pos<<11);
	gpio_output  = ball_xpos;
	gpio_output  = gpio_output  | (ball_ypos<<11);
	XGpio_DiscreteWrite(&gpio, 1, gpio_output);
	XGpio_DiscreteWrite(&gpio, 2, gpio2_output);
	usleep(2500);
	}
}
